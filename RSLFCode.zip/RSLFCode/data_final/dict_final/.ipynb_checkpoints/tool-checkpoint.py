import pandas as pd

# Load the Excel file
excel_file = '中文自杀词典重标注.xlsx'

# Read the first sheet of the Excel file into a DataFrame
df = pd.read_excel(excel_file, sheet_name=0)

# Save the DataFrame to a CSV file
csv_file = 'dict.csv'
df.to_csv(csv_file, index=False)

print(f'Excel file {excel_file} has been converted to CSV file {csv_file}')
